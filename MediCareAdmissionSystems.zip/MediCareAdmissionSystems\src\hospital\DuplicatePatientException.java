package hospital;

/**
 * Custom checked exception thrown when a patient is registered with a
 * Patient ID that already exists in the system.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class DuplicatePatientException extends Exception {

    public DuplicatePatientException(String message) {
        // Pass the message to the Exception superclass
        super(message);
    }
}
