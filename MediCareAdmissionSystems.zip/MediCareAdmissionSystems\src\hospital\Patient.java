package hospital;

/**
 * Base class that stores the information of any patient at MediCare Hospital.
 * Outpatients and Emergency patients use this class directly. Inpatients use
 * the Inpatient subclass (inheritance).
 *
 * All fields are private (information hiding) and are validated in the
 * setters so that bad data never gets stored.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class Patient {

    // Private attributes (information hiding)
    private String patientId;
    private String firstName;
    private String lastName;
    private int age;
    private String gender;
    private String medicalCondition;
    private PatientCategory category;

    /**
     * Constructor that creates a patient and validates every value.
     *
     * @throws IllegalArgumentException if any value is invalid
     */
    public Patient(String patientId, String firstName, String lastName,
            int age, String gender, String medicalCondition,
            PatientCategory category) {

        setPatientId(patientId);
        setFirstName(firstName);
        setLastName(lastName);
        setAge(age);
        setGender(gender);
        setMedicalCondition(medicalCondition);

        // The category cannot be null
        if (category == null) {
            throw new IllegalArgumentException("Patient category is required.");
        }
        this.category = category;
    }

    // ---------------- Getters ----------------
    public String getPatientId() {
        return patientId;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getAge() {
        return age;
    }

    public String getGender() {
        return gender;
    }

    public String getMedicalCondition() {
        return medicalCondition;
    }

    public PatientCategory getCategory() {
        return category;
    }

    // ---------------- Setters (with validation) ----------------
    public final void setPatientId(String patientId) {
        if (patientId == null || patientId.trim().isEmpty()) {
            throw new IllegalArgumentException("Patient ID cannot be empty.");
        }
        // Trim and make upper case so "p001" and "P001" are the same ID
        this.patientId = patientId.trim().toUpperCase();
    }

    public final void setFirstName(String firstName) {
        if (firstName == null || firstName.trim().isEmpty()) {
            throw new IllegalArgumentException("First name cannot be empty.");
        }
        this.firstName = firstName.trim();
    }

    public final void setLastName(String lastName) {
        if (lastName == null || lastName.trim().isEmpty()) {
            throw new IllegalArgumentException("Last name cannot be empty.");
        }
        this.lastName = lastName.trim();
    }

    public final void setAge(int age) {
        if (age < 0 || age > 120) {
            throw new IllegalArgumentException("Age must be between 0 and 120.");
        }
        this.age = age;
    }

    public final void setGender(String gender) {
        if (gender == null || gender.trim().isEmpty()) {
            throw new IllegalArgumentException("Gender cannot be empty.");
        }
        this.gender = gender.trim();
    }

    public final void setMedicalCondition(String medicalCondition) {
        if (medicalCondition == null || medicalCondition.trim().isEmpty()) {
            throw new IllegalArgumentException("Medical condition cannot be empty.");
        }
        this.medicalCondition = medicalCondition.trim();
    }

    /**
     * Prints the patient's details to the console. The Inpatient class
     * overrides this method to add the ward and bed information.
     */
    public void displayDetails() {
        System.out.println("Patient ID        : " + patientId);
        System.out.println("Name              : " + firstName + " " + lastName);
        System.out.println("Age               : " + age);
        System.out.println("Gender            : " + gender);
        System.out.println("Medical condition : " + medicalCondition);
        System.out.println("Category          : " + category.getDisplayName());
    }
}
