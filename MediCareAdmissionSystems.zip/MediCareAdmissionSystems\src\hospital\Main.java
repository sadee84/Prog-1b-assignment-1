package hospital;

import java.util.Scanner;

/**
 * Console-based, menu-driven user interface for the MediCare Hospital
 * Patient Admission System.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class Main {

    // One Scanner shared by all methods (Oracle, n.d.)
    private static final Scanner input = new Scanner(System.in);

    // One HospitalSystem object that holds all the data
    private static final HospitalSystem system = new HospitalSystem();

    public static void main(String[] args) {
        int choice = -1;

        System.out.println("=======================================");
        System.out.println("  MEDICARE HOSPITAL ADMISSION SYSTEM");
        System.out.println("=======================================");

        // Keep showing the menu until the user chooses 0 (Exit)
        while (choice != 0) {
            showMenu();
            choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1:
                    registerPatient();
                    break;
                case 2:
                    searchPatient();
                    break;
                case 3:
                    updatePatient();
                    break;
                case 4:
                    deletePatient();
                    break;
                case 5:
                    system.displayAllPatients();
                    break;
                case 6:
                    allocateBed();
                    break;
                case 7:
                    releaseBed();
                    break;
                case 8:
                    system.displayWardLayout();
                    break;
                case 9:
                    system.displayAvailableBeds();
                    break;
                case 10:
                    system.displayOccupiedBeds();
                    break;
                case 11:
                    system.generateWardReport();
                    break;
                case 12:
                    sortPatients();
                    break;
                case 0:
                    System.out.println("Goodbye. Data held in memory will now be cleared.");
                    break;
                default:
                    System.out.println("Invalid choice. Please select 0 to 12.");
            }
        }
        input.close();
    }

    /**
     * Prints the main menu.
     */
    private static void showMenu() {
        System.out.println("\n----------- MAIN MENU -----------");
        System.out.println(" 1. Register a new patient");
        System.out.println(" 2. Search for a patient (Patient ID)");
        System.out.println(" 3. Update a patient's details");
        System.out.println(" 4. Delete a patient");
        System.out.println(" 5. Display all registered patients");
        System.out.println(" 6. Allocate a bed to an inpatient");
        System.out.println(" 7. Release a bed (discharge)");
        System.out.println(" 8. Display ward layout");
        System.out.println(" 9. Display available beds");
        System.out.println("10. Display occupied beds");
        System.out.println("11. Generate ward report");
        System.out.println("12. Sort patients (surname or ID)");
        System.out.println(" 0. Exit");
        System.out.println("---------------------------------");
    }

    // ------------------------------------------------------------------
    // Menu actions
    // ------------------------------------------------------------------

    private static void registerPatient() {
        System.out.println("\n--- Register a New Patient ---");

        try {
            String id = readText("Patient ID: ");
            String firstName = readText("First name: ");
            String lastName = readText("Last name: ");
            int age = readInt("Age: ");
            String gender = readText("Gender: ");
            String condition = readText("Medical condition: ");
            PatientCategory category = readCategory();

            Patient patient;

            // Inpatients are stored as Inpatient objects, the rest as Patient
            if (category == PatientCategory.INPATIENT) {
                patient = new Inpatient(id, firstName, lastName, age, gender,
                        condition, HospitalSystem.WARD_NUMBER, Inpatient.NO_BED);
            } else {
                patient = new Patient(id, firstName, lastName, age, gender,
                        condition, category);
            }

            system.registerPatient(patient);
            System.out.println("Patient registered successfully.");

            if (category.requiresBed()) {
                System.out.println("Use option 6 to allocate this inpatient a bed.");
            }

        } catch (DuplicatePatientException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            // Thrown by the Patient setters when data is invalid
            System.out.println("Invalid data: " + e.getMessage());
        }
    }

    private static void searchPatient() {
        System.out.println("\n--- Search for a Patient ---");
        String id = readText("Enter Patient ID: ");

        Patient patient = system.searchPatient(id);
        if (patient == null) {
            System.out.println("No patient found with ID " + id.trim().toUpperCase() + ".");
        } else {
            patient.displayDetails();
        }
    }

    private static void updatePatient() {
        System.out.println("\n--- Update a Patient ---");
        String id = readText("Enter the Patient ID to update: ");

        Patient existing = system.searchPatient(id);
        if (existing == null) {
            System.out.println("No patient found with ID " + id.trim().toUpperCase() + ".");
            return;
        }

        System.out.println("Current details:");
        existing.displayDetails();
        System.out.println("\nEnter the new details:");

        try {
            String firstName = readText("First name: ");
            String lastName = readText("Last name: ");
            int age = readInt("Age: ");
            String gender = readText("Gender: ");
            String condition = readText("Medical condition: ");
            PatientCategory category = readCategory();

            system.updatePatient(id, firstName, lastName, age, gender,
                    condition, category);
            System.out.println("Patient updated successfully.");

        } catch (PatientNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            System.out.println("Invalid data: " + e.getMessage());
        }
    }

    private static void deletePatient() {
        System.out.println("\n--- Delete a Patient ---");
        String id = readText("Enter the Patient ID to delete: ");

        try {
            system.deletePatient(id);
            System.out.println("Patient deleted successfully.");
        } catch (PatientNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void allocateBed() {
        System.out.println("\n--- Allocate a Bed ---");
        system.displayWardLayout();

        String id = readText("Enter the inpatient's Patient ID: ");
        String bed = readText("Enter the bed number (e.g. B05): ");

        try {
            system.allocateBed(id, bed);
            System.out.println("Bed " + bed.trim().toUpperCase()
                    + " allocated successfully.");
        } catch (PatientNotFoundException | BedAllocationException e) {
            // Multi-catch: both exceptions are handled the same way
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void releaseBed() {
        System.out.println("\n--- Release a Bed ---");
        String id = readText("Enter the Patient ID of the discharged patient: ");

        try {
            system.releaseBed(id);
            System.out.println("Bed released successfully.");
        } catch (PatientNotFoundException | BedAllocationException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void sortPatients() {
        System.out.println("\n--- Sort Patients ---");
        System.out.println("1. Sort by surname");
        System.out.println("2. Sort by Patient ID");
        int choice = readInt("Enter your choice: ");

        if (choice == 1) {
            System.out.println("\nPatients sorted by surname:");
            system.displayPatientArray(system.sortPatientsBySurname());
        } else if (choice == 2) {
            System.out.println("\nPatients sorted by Patient ID:");
            system.displayPatientArray(system.sortPatientsById());
        } else {
            System.out.println("Invalid choice.");
        }
    }

    // ------------------------------------------------------------------
    // Input helper methods
    // ------------------------------------------------------------------

    /**
     * Reads a whole number. Keeps asking until the user types a valid number
     * (exception handling for NumberFormatException).
     */
    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String text = input.nextLine();

            try {
                return Integer.parseInt(text.trim());
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }

    /**
     * Reads a line of text from the user.
     */
    private static String readText(String prompt) {
        System.out.print(prompt);
        return input.nextLine();
    }

    /**
     * Shows the category menu and keeps asking until a valid choice is made.
     */
    private static PatientCategory readCategory() {
        PatientCategory category = null;

        while (category == null) {
            System.out.println("Patient category:");
            System.out.println("  1. Inpatient");
            System.out.println("  2. Outpatient");
            System.out.println("  3. Emergency");
            category = PatientCategory.fromChoice(readInt("Enter 1, 2 or 3: "));

            if (category == null) {
                System.out.println("Invalid category. Please try again.");
            }
        }
        return category;
    }
}

/*
 * REFERENCE LIST (IIE Harvard Anglia)
 *
 * JUnit Team (n.d.) JUnit 4. Available at: https://junit.org/junit4/ (Accessed: 17 October 2026).
 *
 * Oracle (n.d.) Java Platform, Standard Edition API specification. Available at: https://docs.oracle.com/en/java/javase/17/docs/api/ (Accessed: 17 October 2026).
 */
