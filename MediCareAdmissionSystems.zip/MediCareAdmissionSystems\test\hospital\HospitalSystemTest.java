package hospital;

import static org.junit.Assert.*;

import java.util.ArrayList;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit 4 tests for the HospitalSystem class (JUnit Team, n.d.).
 * A fresh HospitalSystem is created before every test so the tests do not
 * affect each other.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class HospitalSystemTest {

    private HospitalSystem system;

    /**
     * Runs before each test: creates an empty system.
     */
    @Before
    public void setUp() {
        system = new HospitalSystem();
    }

    // Helper: creates an inpatient object quickly
    private Inpatient makeInpatient(String id, String lastName) {
        return new Inpatient(id, "Test", lastName, 30, "Female", "Flu",
                HospitalSystem.WARD_NUMBER, Inpatient.NO_BED);
    }

    // Helper: creates an outpatient object quickly
    private Patient makeOutpatient(String id, String lastName) {
        return new Patient(id, "Test", lastName, 40, "Male", "Check-up",
                PatientCategory.OUTPATIENT);
    }

    // ---------------- Patient management ----------------

    @Test
    public void testRegisterPatient() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        assertEquals(1, system.countPatients());
        assertNotNull(system.searchPatient("P001"));
    }

    @Test
    public void testSearchPatientFound() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        Patient found = system.searchPatient("P001");
        assertEquals("Dlamini", found.getLastName());
    }

    @Test
    public void testSearchPatientNotFound() {
        assertNull(system.searchPatient("P999"));
    }

    @Test
    public void testUpdatePatient() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        system.updatePatient("P001", "Sipho", "Nkosi", 45, "Male",
                "Back pain", PatientCategory.OUTPATIENT);

        Patient updated = system.searchPatient("P001");
        assertEquals("Sipho", updated.getFirstName());
        assertEquals("Nkosi", updated.getLastName());
        assertEquals(45, updated.getAge());
        assertEquals("Back pain", updated.getMedicalCondition());
    }

    @Test
    public void testUpdateNonExistingPatientThrowsException() {
        assertThrows(PatientNotFoundException.class, () -> {
            system.updatePatient("P404", "A", "B", 20, "Male", "Flu",
                    PatientCategory.OUTPATIENT);
        });
    }

    @Test
    public void testDeletePatient() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        system.deletePatient("P001");

        assertEquals(0, system.countPatients());
        assertNull(system.searchPatient("P001"));
    }

    @Test
    public void testDeletePatientFreesBed() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));
        system.allocateBed("P001", "B01");

        system.deletePatient("P001");

        // The bed must be available again after the patient is deleted
        assertEquals(0, system.countOccupiedBeds());
    }

    @Test
    public void testPreventDuplicatePatientIds() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        assertThrows(DuplicatePatientException.class, () -> {
            system.registerPatient(makeOutpatient("P001", "Nkosi"));
        });
        // Only the first patient must be stored
        assertEquals(1, system.countPatients());
    }

    @Test
    public void testInvalidAgeThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> {
            new Patient("P001", "A", "B", -5, "Male", "Flu",
                    PatientCategory.OUTPATIENT);
        });
    }

    // ---------------- Bed management ----------------

    @Test
    public void testAllocateBed() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));

        system.allocateBed("P001", "B05");

        Inpatient inpatient = (Inpatient) system.searchPatient("P001");
        assertEquals("B05", inpatient.getBedNumber());
        assertEquals(1, system.countOccupiedBeds());
    }

    @Test
    public void testReleaseBed() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));
        system.allocateBed("P001", "B05");

        system.releaseBed("P001");

        Inpatient inpatient = (Inpatient) system.searchPatient("P001");
        assertFalse(inpatient.hasBed());
        assertEquals(0, system.countOccupiedBeds());
    }

    @Test
    public void testPreventAllocatingOccupiedBed() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));
        system.registerPatient(makeInpatient("P002", "Nkosi"));
        system.allocateBed("P001", "B01");

        // B01 is already taken by P001
        assertThrows(BedAllocationException.class, () -> {
            system.allocateBed("P002", "B01");
        });
    }

    @Test
    public void testPreventBedAllocationWhenAllBedsOccupied() throws Exception {
        // Fill all 20 beds (B01 to B20)
        for (int i = 1; i <= HospitalSystem.TOTAL_BEDS; i++) {
            String id = String.format("P%03d", i);
            system.registerPatient(makeInpatient(id, "Surname" + i));
            system.allocateBed(id, String.format("B%02d", i));
        }
        assertEquals(HospitalSystem.TOTAL_BEDS, system.countOccupiedBeds());

        // A 21st inpatient cannot get a bed
        system.registerPatient(makeInpatient("P021", "Extra"));
        BedAllocationException e = assertThrows(BedAllocationException.class, () -> {
            system.allocateBed("P021", "B01");
        });
        assertTrue(e.getMessage().contains("No beds are available"));
    }

    @Test
    public void testOnlyInpatientsCanBeAllocatedBeds() throws Exception {
        system.registerPatient(makeOutpatient("P001", "Dlamini"));

        assertThrows(BedAllocationException.class, () -> {
            system.allocateBed("P001", "B01");
        });
    }

    @Test
    public void testInpatientCannotOccupyTwoBeds() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));
        system.allocateBed("P001", "B01");

        assertThrows(BedAllocationException.class, () -> {
            system.allocateBed("P001", "B02");
        });
    }

    @Test
    public void testAvailableAndOccupiedBeds() throws Exception {
        system.registerPatient(makeInpatient("P001", "Dlamini"));
        system.allocateBed("P001", "B01");

        ArrayList<Bed> available = system.getAvailableBeds();
        ArrayList<Bed> occupied = system.getOccupiedBeds();

        assertEquals(19, available.size());
        assertEquals(1, occupied.size());
        assertEquals("B01", occupied.get(0).getBedNumber());
    }

    @Test
    public void testOccupancyPercentage() throws Exception {
        // 5 occupied beds out of 20 = 25%
        for (int i = 1; i <= 5; i++) {
            String id = "P00" + i;
            system.registerPatient(makeInpatient(id, "Surname" + i));
            system.allocateBed(id, "B0" + i);
        }
        assertEquals(25.0, system.getOccupancyPercentage(), 0.001);
    }

    // ---------------- Sorting ----------------

    @Test
    public void testSortPatientsBySurname() throws Exception {
        system.registerPatient(makeOutpatient("P003", "Zulu"));
        system.registerPatient(makeOutpatient("P001", "Dlamini"));
        system.registerPatient(makeOutpatient("P002", "Nkosi"));

        Patient[] sorted = system.sortPatientsBySurname();

        assertEquals("Dlamini", sorted[0].getLastName());
        assertEquals("Nkosi", sorted[1].getLastName());
        assertEquals("Zulu", sorted[2].getLastName());
    }

    @Test
    public void testSortPatientsById() throws Exception {
        system.registerPatient(makeOutpatient("P003", "Zulu"));
        system.registerPatient(makeOutpatient("P001", "Dlamini"));
        system.registerPatient(makeOutpatient("P002", "Nkosi"));

        Patient[] sorted = system.sortPatientsById();

        assertEquals("P001", sorted[0].getPatientId());
        assertEquals("P002", sorted[1].getPatientId());
        assertEquals("P003", sorted[2].getPatientId());
    }
}
