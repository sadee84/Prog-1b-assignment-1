package hospital;

/**
 * Custom checked exception thrown when a bed cannot be allocated or released
 * (for example the bed is occupied or the ward is full).
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class BedAllocationException extends Exception {

    public BedAllocationException(String message) {
        super(message);
    }
}
