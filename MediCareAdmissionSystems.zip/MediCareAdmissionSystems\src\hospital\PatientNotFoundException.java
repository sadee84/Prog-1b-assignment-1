package hospital;

/**
 * Custom checked exception thrown when a Patient ID cannot be found.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class PatientNotFoundException extends Exception {

    public PatientNotFoundException(String message) {
        super(message);
    }
}
