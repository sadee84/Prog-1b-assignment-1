package hospital;

import java.util.ArrayList;

/**
 * Handles all the business logic of the Hospital Patient Admission System:
 * patient management, bed management, reports and sorting.
 *
 * Patients are stored in an ArrayList and the 20 beds are stored in a
 * two-dimensional array (4 rows x 5 columns). Everything is kept in memory
 * while the program runs.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class HospitalSystem {

    // Constants so we do not use "magic numbers" in the code
    public static final int WARD_NUMBER = 1;
    public static final int ROWS = 4;
    public static final int COLUMNS = 5;
    public static final int TOTAL_BEDS = ROWS * COLUMNS;

    // ArrayList of all registered patients (Oracle, n.d.)
    private ArrayList<Patient> patients;

    // Two-dimensional array that represents the ward layout
    private Bed[][] wardLayout;

    /**
     * Creates an empty system and builds the 4 x 5 ward of beds.
     */
    public HospitalSystem() {
        patients = new ArrayList<>();
        wardLayout = new Bed[ROWS][COLUMNS];

        int bedCounter = 1;

        // Nested loops: outer loop = rows, inner loop = columns
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                // %02d pads the number with a zero, e.g. 1 becomes 01
                wardLayout[row][col] = new Bed(String.format("B%02d", bedCounter));
                bedCounter++;
            }
        }
    }

    // =====================================================================
    // FEATURE 1: PATIENT MANAGEMENT
    // =====================================================================

    /**
     * Registers a new patient.
     *
     * @throws DuplicatePatientException if the Patient ID is already used
     */
    public void registerPatient(Patient patient) throws DuplicatePatientException {
        if (patient == null) {
            throw new IllegalArgumentException("Patient cannot be null.");
        }

        // Prevent duplicate Patient IDs
        if (searchPatient(patient.getPatientId()) != null) {
            throw new DuplicatePatientException("A patient with ID "
                    + patient.getPatientId() + " already exists.");
        }
        patients.add(patient);
    }

    /**
     * Searches for a patient using the Patient ID.
     *
     * @return the Patient, or null if no patient has that ID
     */
    public Patient searchPatient(String patientId) {
        int index = findPatientIndex(patientId);
        if (index == -1) {
            return null;
        }
        return patients.get(index);
    }

    /**
     * Updates the details of an existing patient. If the category changes,
     * a new object of the correct class replaces the old one (an Inpatient
     * object is needed for inpatients, a Patient object for the others).
     *
     * @throws PatientNotFoundException if the ID does not exist
     */
    public void updatePatient(String patientId, String firstName,
            String lastName, int age, String gender, String medicalCondition,
            PatientCategory newCategory) throws PatientNotFoundException {

        int index = findPatientIndex(patientId);
        if (index == -1) {
            throw new PatientNotFoundException("No patient found with ID "
                    + patientId + ".");
        }

        Patient existing = patients.get(index);

        // Build the replacement first. If any value is invalid the
        // constructor throws an exception and nothing has been changed yet.
        Patient replacement;
        if (newCategory == PatientCategory.INPATIENT) {
            replacement = new Inpatient(existing.getPatientId(), firstName,
                    lastName, age, gender, medicalCondition,
                    WARD_NUMBER, Inpatient.NO_BED);
        } else if (newCategory != null) {
            replacement = new Patient(existing.getPatientId(), firstName,
                    lastName, age, gender, medicalCondition, newCategory);
        } else {
            throw new IllegalArgumentException("Patient category is required.");
        }

        // Handle the bed if the old record was an inpatient with a bed
        if (existing instanceof Inpatient) {
            Inpatient oldInpatient = (Inpatient) existing;

            if (oldInpatient.hasBed()) {
                if (replacement instanceof Inpatient) {
                    // Still an inpatient: keep the same bed
                    ((Inpatient) replacement).setBedNumber(oldInpatient.getBedNumber());
                } else {
                    // No longer an inpatient: free the bed
                    freeBed(oldInpatient.getBedNumber());
                }
            }
        }

        patients.set(index, replacement);
    }

    /**
     * Deletes a patient. If the patient is occupying a bed, the bed is
     * released first.
     *
     * @throws PatientNotFoundException if the ID does not exist
     */
    public void deletePatient(String patientId) throws PatientNotFoundException {
        int index = findPatientIndex(patientId);
        if (index == -1) {
            throw new PatientNotFoundException("No patient found with ID "
                    + patientId + ".");
        }

        Patient patient = patients.get(index);

        // Free the bed so it does not stay occupied by a deleted patient
        if (patient instanceof Inpatient) {
            Inpatient inpatient = (Inpatient) patient;
            if (inpatient.hasBed()) {
                freeBed(inpatient.getBedNumber());
            }
        }
        patients.remove(index);
    }

    /**
     * @return a copy of the list of all registered patients
     */
    public ArrayList<Patient> getAllPatients() {
        // Return a copy so outside code cannot change our private list
        return new ArrayList<>(patients);
    }

    /**
     * Helper method: finds the position of a patient in the ArrayList.
     *
     * @return the index, or -1 if not found
     */
    private int findPatientIndex(String patientId) {
        if (patientId == null) {
            return -1;
        }
        String searchId = patientId.trim().toUpperCase();

        for (int i = 0; i < patients.size(); i++) {
            if (patients.get(i).getPatientId().equals(searchId)) {
                return i;
            }
        }
        return -1;
    }

    // =====================================================================
    // FEATURE 2: BED MANAGEMENT
    // =====================================================================

    /**
     * Allocates an available bed to an inpatient.
     *
     * @throws PatientNotFoundException if the patient does not exist
     * @throws BedAllocationException   if the bed cannot be allocated
     */
    public void allocateBed(String patientId, String bedNumber)
            throws PatientNotFoundException, BedAllocationException {

        Patient patient = searchPatient(patientId);
        if (patient == null) {
            throw new PatientNotFoundException("No patient found with ID "
                    + patientId + ".");
        }

        // Only inpatients may be allocated a bed
        if (!patient.getCategory().requiresBed()) {
            throw new BedAllocationException("Only inpatients may be allocated a bed.");
        }

        Inpatient inpatient = (Inpatient) patient;

        // Each inpatient may occupy only one bed
        if (inpatient.hasBed()) {
            throw new BedAllocationException("Patient already occupies bed "
                    + inpatient.getBedNumber() + ".");
        }

        // Prevent bed allocation if no beds are available
        if (countOccupiedBeds() == TOTAL_BEDS) {
            throw new BedAllocationException("No beds are available. The ward is full.");
        }

        Bed bed = findBed(bedNumber);
        if (bed == null) {
            throw new BedAllocationException("Bed " + bedNumber + " does not exist.");
        }

        // A bed can only be assigned to one inpatient at a time
        if (bed.isOccupied()) {
            throw new BedAllocationException("Bed " + bed.getBedNumber()
                    + " is already occupied.");
        }

        // Everything is valid, so link the patient and the bed
        bed.assign(inpatient.getPatientId());
        inpatient.setBedNumber(bed.getBedNumber());
    }

    /**
     * Releases the bed of a patient who is discharged.
     *
     * @throws PatientNotFoundException if the patient does not exist
     * @throws BedAllocationException   if the patient has no bed
     */
    public void releaseBed(String patientId)
            throws PatientNotFoundException, BedAllocationException {

        Patient patient = searchPatient(patientId);
        if (patient == null) {
            throw new PatientNotFoundException("No patient found with ID "
                    + patientId + ".");
        }

        // instanceof checks that the object really is an Inpatient
        if (!(patient instanceof Inpatient)) {
            throw new BedAllocationException("This patient is not an inpatient.");
        }

        Inpatient inpatient = (Inpatient) patient;
        if (!inpatient.hasBed()) {
            throw new BedAllocationException("This patient does not have a bed.");
        }

        freeBed(inpatient.getBedNumber());
        inpatient.setBedNumber(Inpatient.NO_BED);
    }

    /**
     * Helper method: makes a bed available again.
     */
    private void freeBed(String bedNumber) {
        Bed bed = findBed(bedNumber);
        if (bed != null) {
            bed.release();
        }
    }

    /**
     * Helper method: searches the 2D array for a bed number.
     *
     * @return the Bed, or null if it does not exist
     */
    private Bed findBed(String bedNumber) {
        if (bedNumber == null) {
            return null;
        }
        String searchNumber = bedNumber.trim().toUpperCase();

        // Nested loops to search the 2D array
        for (int row = 0; row < wardLayout.length; row++) {
            for (int col = 0; col < wardLayout[row].length; col++) {
                if (wardLayout[row][col].getBedNumber().equals(searchNumber)) {
                    return wardLayout[row][col];
                }
            }
        }
        return null;
    }

    /**
     * @return a list of all beds that are available
     */
    public ArrayList<Bed> getAvailableBeds() {
        ArrayList<Bed> available = new ArrayList<>();

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (!wardLayout[row][col].isOccupied()) {
                    available.add(wardLayout[row][col]);
                }
            }
        }
        return available;
    }

    /**
     * @return a list of all beds that are occupied
     */
    public ArrayList<Bed> getOccupiedBeds() {
        ArrayList<Bed> occupied = new ArrayList<>();

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                if (wardLayout[row][col].isOccupied()) {
                    occupied.add(wardLayout[row][col]);
                }
            }
        }
        return occupied;
    }

    /**
     * Displays the complete ward layout. Occupied beds are marked with *.
     */
    public void displayWardLayout() {
        System.out.println("---------- WARD " + WARD_NUMBER + " LAYOUT ----------");

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLUMNS; col++) {
                Bed bed = wardLayout[row][col];

                if (bed.isOccupied()) {
                    System.out.print(bed.getBedNumber() + "* ");
                } else {
                    System.out.print(bed.getBedNumber() + "  ");
                }
            }
            System.out.println();
        }
        System.out.println("(* = occupied)");
    }

    /**
     * Displays all available beds.
     */
    public void displayAvailableBeds() {
        ArrayList<Bed> available = getAvailableBeds();
        System.out.println("---------- AVAILABLE BEDS ----------");

        if (available.isEmpty()) {
            System.out.println("There are no available beds.");
        } else {
            for (Bed bed : available) {
                System.out.println(bed);
            }
        }
    }

    /**
     * Displays all occupied beds.
     */
    public void displayOccupiedBeds() {
        ArrayList<Bed> occupied = getOccupiedBeds();
        System.out.println("---------- OCCUPIED BEDS ----------");

        if (occupied.isEmpty()) {
            System.out.println("There are no occupied beds.");
        } else {
            for (Bed bed : occupied) {
                System.out.println(bed);
            }
        }
    }

    // =====================================================================
    // FEATURE 3: REPORTS
    // =====================================================================

    /**
     * @return the number of registered patients
     */
    public int countPatients() {
        return patients.size();
    }

    /**
     * @return the number of occupied beds
     */
    public int countOccupiedBeds() {
        return getOccupiedBeds().size();
    }

    /**
     * @return the ward occupancy as a percentage (0 to 100)
     */
    public double getOccupancyPercentage() {
        // Cast to double so the division is not an integer division
        return ((double) countOccupiedBeds() / TOTAL_BEDS) * 100;
    }

    /**
     * Displays every registered patient (full details).
     */
    public void displayAllPatients() {
        System.out.println("---------- ALL REGISTERED PATIENTS ----------");

        if (patients.isEmpty()) {
            System.out.println("No patients are registered.");
            return;
        }

        for (Patient patient : patients) {
            // Polymorphism: Java calls the correct displayDetails() method
            patient.displayDetails();
            System.out.println("---------------------------------------------");
        }
    }

    /**
     * Generates the full ward report.
     */
    public void generateWardReport() {
        System.out.println("\n=========== MEDICARE WARD REPORT ===========");
        displayAllPatients();
        displayAvailableBeds();
        displayOccupiedBeds();
        System.out.println("---------- SUMMARY ----------");
        System.out.println("Total registered patients : " + countPatients());
        System.out.println("Total occupied beds       : " + countOccupiedBeds());
        System.out.printf("Ward occupancy            : %.1f%%%n", getOccupancyPercentage());
        System.out.println("=============================================");
    }

    // =====================================================================
    // SORTING (arrays are passed to methods and the length field is used)
    // =====================================================================

    /**
     * @return a new array of the patients sorted by surname (A to Z)
     */
    public Patient[] sortPatientsBySurname() {
        // Copy the ArrayList into an array and sort the array
        Patient[] array = patients.toArray(new Patient[0]);
        selectionSortBySurname(array);
        return array;
    }

    /**
     * @return a new array of the patients sorted by Patient ID (A to Z)
     */
    public Patient[] sortPatientsById() {
        Patient[] array = patients.toArray(new Patient[0]);
        selectionSortById(array);
        return array;
    }

    /**
     * Selection sort by surname. The array is passed to the method and
     * sorted in place. If surnames match, the first name is used.
     */
    private void selectionSortBySurname(Patient[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int smallest = i;

            for (int j = i + 1; j < array.length; j++) {
                int result = array[j].getLastName()
                        .compareToIgnoreCase(array[smallest].getLastName());

                // Same surname: compare the first names instead
                if (result == 0) {
                    result = array[j].getFirstName()
                            .compareToIgnoreCase(array[smallest].getFirstName());
                }

                if (result < 0) {
                    smallest = j;
                }
            }

            // Swap the smallest item into position i
            Patient temp = array[i];
            array[i] = array[smallest];
            array[smallest] = temp;
        }
    }

    /**
     * Selection sort by Patient ID.
     */
    private void selectionSortById(Patient[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            int smallest = i;

            for (int j = i + 1; j < array.length; j++) {
                if (array[j].getPatientId().compareTo(array[smallest].getPatientId()) < 0) {
                    smallest = j;
                }
            }

            Patient temp = array[i];
            array[i] = array[smallest];
            array[smallest] = temp;
        }
    }

    /**
     * Prints a sorted array of patients (array passed to a method and the
     * length field used to loop through it).
     */
    public void displayPatientArray(Patient[] array) {
        if (array.length == 0) {
            System.out.println("No patients are registered.");
            return;
        }

        for (int i = 0; i < array.length; i++) {
            array[i].displayDetails();
            System.out.println("---------------------------------------------");
        }
    }
}
