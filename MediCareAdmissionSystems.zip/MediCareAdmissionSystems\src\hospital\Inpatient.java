package hospital;

/**
 * An Inpatient is a Patient who stays in hospital, so we also store the
 * ward number and the bed number. This class inherits from Patient
 * (Oracle, n.d.).
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class Inpatient extends Patient {

    /** Text stored in bedNumber when no bed has been allocated yet. */
    public static final String NO_BED = "Not allocated";

    private int wardNumber;
    private String bedNumber;

    /**
     * Constructor. super() sets up the attributes inherited from Patient.
     * The category is always INPATIENT for this class.
     */
    public Inpatient(String patientId, String firstName, String lastName,
            int age, String gender, String medicalCondition,
            int wardNumber, String bedNumber) {

        // Call the Patient constructor to initialise the inherited attributes
        super(patientId, firstName, lastName, age, gender,
                medicalCondition, PatientCategory.INPATIENT);

        this.wardNumber = wardNumber;
        this.bedNumber = bedNumber;
    }

    public int getWardNumber() {
        return wardNumber;
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public void setBedNumber(String bedNumber) {
        this.bedNumber = bedNumber;
    }

    /**
     * @return true if this inpatient currently has a bed
     */
    public boolean hasBed() {
        return !bedNumber.equals(NO_BED);
    }

    /**
     * Overrides Patient.displayDetails() so the ward and bed are also shown.
     */
    @Override
    public void displayDetails() {
        // Reuse the superclass method for the common details
        super.displayDetails();
        System.out.println("Ward number       : " + wardNumber);
        System.out.println("Bed number        : " + bedNumber);
    }
}
