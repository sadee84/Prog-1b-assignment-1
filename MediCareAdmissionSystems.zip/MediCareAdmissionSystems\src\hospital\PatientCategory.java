package hospital;

/**
 * Enum that represents the three categories of patients treated at MediCare
 * Hospital. An enum is used so that only these three values are possible
 * (Oracle, n.d.).
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public enum PatientCategory {

    // Each constant has a friendly name that is shown to the user
    INPATIENT("Inpatient"),
    OUTPATIENT("Outpatient"),
    EMERGENCY("Emergency");

    // Text that is displayed on the console
    private final String displayName;

    /**
     * Enum constructor (always private). Stores the display name.
     */
    PatientCategory(String displayName) {
        this.displayName = displayName;
    }

    /**
     * Enum method: returns the friendly name of the category.
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Enum method: only inpatients may be allocated a hospital bed.
     *
     * @return true if this category needs a bed
     */
    public boolean requiresBed() {
        return this == INPATIENT;
    }

    /**
     * Enum method: converts a menu choice (1, 2 or 3) into a category.
     *
     * @param choice the number the user typed in
     * @return the matching category, or null if the choice is invalid
     */
    public static PatientCategory fromChoice(int choice) {
        // values() returns every constant of the enum in an array
        PatientCategory[] all = PatientCategory.values();

        // Choice 1 is index 0, choice 2 is index 1, and so on
        if (choice >= 1 && choice <= all.length) {
            return all[choice - 1];
        }
        return null;
    }
}
