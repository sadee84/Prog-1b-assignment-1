package hospital;

/**
 * Represents a single hospital bed. Fields are private (information hiding)
 * and can only be changed through the methods below.
 *
 * @author Sade Mzila
 * Module: PROG1B
 * Institution: Emeris University, Sandton Campus
 */
public class Bed {

    private String bedNumber;     // e.g. "B01"
    private boolean occupied;     // true when a patient is using the bed
    private String patientId;     // ID of the patient in the bed (or empty)

    /**
     * Creates an empty (available) bed.
     */
    public Bed(String bedNumber) {
        this.bedNumber = bedNumber;
        this.occupied = false;
        this.patientId = "";
    }

    public String getBedNumber() {
        return bedNumber;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public String getPatientId() {
        return patientId;
    }

    /**
     * Marks the bed as occupied by the given patient.
     */
    public void assign(String patientId) {
        this.occupied = true;
        this.patientId = patientId;
    }

    /**
     * Marks the bed as available again.
     */
    public void release() {
        this.occupied = false;
        this.patientId = "";
    }

    @Override
    public String toString() {
        if (occupied) {
            return bedNumber + " - Occupied by patient " + patientId;
        }
        return bedNumber + " - Available";
    }
}
